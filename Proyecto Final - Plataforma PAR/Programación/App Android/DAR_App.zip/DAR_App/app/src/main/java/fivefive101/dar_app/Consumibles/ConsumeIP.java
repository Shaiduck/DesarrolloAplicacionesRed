package fivefive101.dar_app.Consumibles;

/**
 * Created by Shaiduck on 5/30/2015.
 */
public class ConsumeIP {

    public int idPaquete;

    public String macDestino;
    public String macFuente;
    public String ipDestino;
    public String ipFuente;

    public int getIdPaquete() {
        return idPaquete;
    }

    public void setIdPaquete(int idPaquete) {
        this.idPaquete = idPaquete;
    }

    public String getMacDestino() {
        return macDestino;
    }

    public void setMacDestino(String macDestino) {
        this.macDestino = macDestino;
    }

    public String getMacFuente() {
        return macFuente;
    }

    public void setMacFuente(String macFuente) {
        this.macFuente = macFuente;
    }

    public String getIpDestino() {
        return ipDestino;
    }

    public void setIpDestino(String ipDestino) {
        this.ipDestino = ipDestino;
    }

    public String getIpFuente() {
        return ipFuente;
    }

    public void setIpFuente(String ipFuente) {
        this.ipFuente = ipFuente;
    }
}
